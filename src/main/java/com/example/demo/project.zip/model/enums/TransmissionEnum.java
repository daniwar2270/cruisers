package com.example.demo.model.enums;

public enum TransmissionEnum {

    Automatic,
    Manual
}
