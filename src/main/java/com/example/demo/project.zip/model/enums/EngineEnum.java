package com.example.demo.model.enums;

public enum EngineEnum {

    Petrol,
    Diesel,
    Hybrid,
    Electric

}
