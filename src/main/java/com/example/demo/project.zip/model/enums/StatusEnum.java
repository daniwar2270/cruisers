package com.example.demo.model.enums;

public enum StatusEnum {

    Reserved,

    Canceled,
    Active,

    Late,

    CompletedOnTime,

    CompletedEarly,
    CompletedLate,





}
