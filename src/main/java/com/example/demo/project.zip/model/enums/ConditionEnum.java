package com.example.demo.model.enums;

public enum ConditionEnum {

    Perfect,
    Good,
    Poor
}
