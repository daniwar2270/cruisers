package com.example.demo.model.enums;

public enum RoleEnum {
    ADMIN,
    USER
}
