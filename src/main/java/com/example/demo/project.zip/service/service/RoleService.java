package com.example.demo.service.service;

public interface RoleService {

    void checkRolesAndSeed();
}
